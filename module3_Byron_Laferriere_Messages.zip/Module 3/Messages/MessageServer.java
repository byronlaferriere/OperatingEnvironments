/**
 * Message server.
 *
 * @author Gagne, Galvin, Silberschatz
 * Operating System Concepts with Java - Eighth Edition
 * Copyright John Wiley & Sons - 2010.
 */
 
import java.net.*;
import java.io.*;

public class MessageServer
{
	public static final int PORT = 6100;

	public static void main(String[] args) {
		Socket client = null;
		ServerSocket sock = null;
		BufferedReader reader = null;

		try {
			sock = new ServerSocket(PORT);
			/* creating a loop using a boolean to check for a valid
                        entry in the variable 'sock'.*/
			while (true) {
				client = sock.accept();

				reader = new BufferedReader(new InputStreamReader(client.getInputStream()));

				Message message = new MessageImpl(reader.readLine());

				/* Using set to define/establish counts of message */
				message.setCounts();

				/* This section is referred to as serializing
                                an object. Once this is done, the write() method
                                is used. The activity will follow as:
                                A. Reading string from socket
                                B. constructing a new object and counting the 
                                number of char's and digits in message
                                C. Obtaining objectoutputstream and writing the 
                                message to output the stream*/
            ObjectOutputStream soos = new ObjectOutputStream(client.getOutputStream());
				soos.writeObject(message);
				System.out.println("wrote message to the socket");

				client.close();
			}
		}
		catch (IOException ioe) {
				System.err.println(ioe);
		}
	}
}
