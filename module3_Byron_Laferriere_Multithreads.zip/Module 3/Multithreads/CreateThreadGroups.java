/**
 * A program that tests your implementation that
 * lists all thread groups 
 * - and threads within each group -
 * in the JVM.
 */


public class CreateThreadGroups
{
	public CreateThreadGroups() {
		/* We learned in the readings this week that alpha and beta 
            threads belong in a 'parent group'. Whereas theta would be consider-
            ed a child of alpha in this case. The hierarchy would be established
            as system-main-alpha-beta-theta. Thread groups are organized using
            tree structuring, which means that system is considered the 'root' 
            of the thread group system*/
		ThreadGroup alpha = new ThreadGroup("alpha");
		ThreadGroup beta = new ThreadGroup("beta");
		ThreadGroup theta = new ThreadGroup(alpha, "theta");

		/* using the 'new' syntax, we can create new threads within each
                group that was previously defined. The order for the syntax goes
                thread name- thread identifier- state of the thread- whether or 
                not the thread is a daemon.*/	
		(new Thread(alpha, new GroupWorker())).start();
		(new Thread(alpha, new GroupWorker())).start();
		(new Thread(alpha, new GroupWorker())).start();
		(new Thread(beta, new GroupWorker())).start();
		(new Thread(theta, new GroupWorker())).start();
		(new Thread(theta, new GroupWorker())).start();
	}

	class GroupWorker implements Runnable
	{
		public void run() {
			while (true) {
				try {
					Thread.sleep(1000);
					for (int i = 0; i < 1000000; i++)
						;
				}
				catch (InterruptedException ie) { }
			}
		}
	}
}
