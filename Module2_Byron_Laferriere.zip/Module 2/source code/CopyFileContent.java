import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class CopyFileContent {

	public static void main(String[] args) {

		/* Comment Here 
            Following the source file location to path destination system call 
            this begins by establishing the location in folder 'File'
            then calls the file name 'sourceFile' and sets it equal to the new 
            destination file 'file1.txt.'
                        */
		File sourceFile = new File("file1.txt");

		/* Comment Here
                System call to acquire output file name
                */
		File destFile = new File("file2.txt");
		
		/* Comment Here
                System call to open input file if file exists, if file does
                not exist then abort
                */
		if (!destFile.exists()) {
			try {
				destFile.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		InputStream input = null;
		OutputStream output = null;

		try {

			/* Comment Here
                    System call to loop reading from input file
                    */
			input = new FileInputStream(sourceFile);

			/* Comment Here
                        System call to loop writing output file
                        */
			output = new FileOutputStream(destFile);

			byte[] buf = new byte[1024];
			int bytesRead;

			while ((bytesRead = input.read(buf)) > 0) {
				output.write(buf, 0, bytesRead);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		finally {
			try {

				if (null != input) {
					input.close();
				}
				
				if (null != output) {
					output.close();
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}