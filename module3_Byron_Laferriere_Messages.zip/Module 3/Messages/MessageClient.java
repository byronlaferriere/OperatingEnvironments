/**
 * Message client.
 *
 * @author Gagne, Galvin, Silberschatz
 * Operating System Concepts with Java - Eighth Edition
 * Copyright John Wiley & Sons - 2010.
 */
 
 
import java.net.*;
import java.io.*;

public class MessageClient
{
	public static final int PORT = 6100;
	public static final String host = "127.0.0.1";

	public static void main(String[] args) throws IOException {
		Socket sock = null;
		
		if (args.length != 1) {
			System.err.println("Usage: java MessageClient <message>");
			System.exit(0);
		}
		
		try {
         /* This section of the code is assigning both a host and port to the 
                    new socket being called 'sock'. We already know from the 
                    rubric and guidelines that the port is 6100. One of the 
                    strategies used to send counts back to the host is for the
                    server to construct an object possessing the following:
                    A. The message received from the client
                    B. A count of char's in the message
                    C. A count of digits in the message*/
			sock = new Socket(host, PORT);

			PrintWriter pout = new PrintWriter(sock.getOutputStream(),true);

			pout.println(args[0]);

			/* Comment Here */
			ObjectInputStream ois = new ObjectInputStream(sock.getInputStream());

			Message message = (Message) ois.readObject();
			System.out.println(message.getCharacterCount());
			System.out.println(message.getDigitCount());
		}
		catch (IOException ioe) {
			System.err.println(ioe);
		}
		catch (ClassNotFoundException cnfe) {
			System.err.println(cnfe);
		}
          finally {
          	sock.close();
          }
	}
}
