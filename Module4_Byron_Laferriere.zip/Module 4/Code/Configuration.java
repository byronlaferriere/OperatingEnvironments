/**
 * XML parser for configuration parameters.
 *
 * You can use this file with your web server.
 * 
 * This maps configuration parameters to a HashMap and are retrieved
 * through the following getter methods:
 *
 * 	public String getLogFile() 
 * 	public String getDocBase() 
 * 	public String getServerName() 
 *
 * Usage:
 * 	Configuration config = new Configuration(<XML configuration file>);
 *
 *	config.getLogFile();
 *	config.getDocBase();
 *	config.getServerName();
 *
 * @author Gagne, Galvin, Silberschatz
 * Operating System Concepts with Java - Eighth Edition
 * Copyright John Wiley & Sons - 2010.
 */

import java.io.*;

import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;

import java.util.Map;
import java.util.HashMap;

public class Configuration extends DefaultHandler
{
    private Map map;
    private String configurationFile;

    /* Configurations can be used to validate whether or not the parameters are
    satisfied or if they need to throw exceptions on simple or fatal errors. 
    This configuration seems to be the validation for the Hashmap*/ 
    public Configuration(String configurationFile) throws ConfigurationException {
	this.configurationFile = configurationFile;

	map = new HashMap();

	try {        
        	// Use the default (non-validating) parser
        	SAXParserFactory factory = SAXParserFactory.newInstance();

        	// Parse the input
        	SAXParser saxParser = factory.newSAXParser();
        	saxParser.parse( new File(configurationFile), this);
	}
	catch (javax.xml.parsers.ParserConfigurationException pce) {
		throw new ConfigurationException("javax.xml.parsers.ParserConfigurationException");
	}
	catch (org.xml.sax.SAXException se) {
		throw new ConfigurationException("org.xml.sax.SAXException");
	}
	catch (java.io.IOException ioe) {
		throw new ConfigurationException("java.io.IOException");
	}
    }


	/* Constructor to start element creation for insertion into the Hashmap
    for storage. Calling four variables to be used within.*/
    public void startElement(String namespaceURI,
                             String lName, 	
                             String qName, 	
                             Attributes attrs)	
    throws SAXException
    {
        String elementName = lName; // element name
        if ("".equals(elementName)) 
		elementName = qName; // namespaceAware = false

	/* This has created a loop to check for attributes until the loop has 
        completed its cycle through however many attributes are present. By
        assigning i = 0 and using the i++ notation, it will do this. It looks
        like if an attribute is present it assigns the string aName to the 
        localName assigned. Then there is a nested loop that will get 'QName' if
        the string is empty.*/
        if (attrs != null) {
            for (int i = 0; i < attrs.getLength(); i++) {
                String aName = attrs.getLocalName(i); // Attr name 
                if ("".equals(aName)) 
			aName = attrs.getQName(i);

		/* This piece of code maps the newly created element to the 
                Hashmap. It combines the variable 'elementName' with a period
                and the + symbol to concatenate it with aName. Then assigns it with
                the getValue.*/
		map.put(elementName+"."+aName,attrs.getValue(i));
            }
        }
    }

	/* Using the getter method to access the hasmap and retrieve the desired
        string under the file name 'logfile.log' that is stored in the table.*/
	public String getLogFile() {
		return (String)map.get("logfile.log");
	}

	/* Using the same getter method to access the hashmap and retrieve the
        desired String under the file name 'context.docBase' that is stored 
        in the hashmap.*/
	public String getDocBase() {
		return (String)map.get("context.docBase");
	}

	/* Lastly, using the getter method again to access the hashmap and 
        retrieve the String under the file name 'webserver.title'*/
	public String getServerName() {
		return (String)map.get("webserver.title");
	}
}
